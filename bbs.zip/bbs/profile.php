<?php
// Include the database connection file
include('db_connection.php');
session_start(); // Start session to capture userID

// Check if the user is logged in (Ensure userID is available)
if (!isset($_SESSION['userID'])) {
    echo "Please log in to view your profile.";
    exit;
}

// Get the logged-in user's ID
$userID = $_SESSION['userID'];

// SQL query to fetch user details
$query = "SELECT username, email FROM users WHERE userID = ?";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="profile.css">
</head>
<body>
<?php

if ($stmt1 = $conn->prepare($query)) {
    // Bind the parameters
    $stmt1->bind_param("i", $userID);
    
    // Execute the query
    $stmt1->execute();
    
    // Get the result
    $result = $stmt1->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo '<div class="profile-container">';
        echo "<h2>User Profile</h2>";
        echo "<p><strong>Username:</strong> " . $user['username'] . "</p>";
        echo "<p><strong>Email:</strong> " . $user['email'] . "</p>";

        echo '<form method="POST" action="profile.php" style="display: inline;">
                <button type="submit" name="delete_account" onclick="return confirm(\'Are you sure you want to delete your account?\');">Delete Account</button>
              </form>';
        echo '<form method="POST" action="profile.php" style="display: inline; margin-top: 10px;">
              <button type="submit" name="logout" onclick="return confirm(\'Are you sure you want to logout?\');">Logout</button>
            </form>';
        echo '<br><br>
              <button id="changePasswordBtn">Change Password</button>
              <div id="changePasswordForm" style="display: none; margin-top: 20px;">
                <form method="POST" action="profile.php">
                  <label>Current Password:</label><br>
                  <input type="password" name="current_password" required><br>
                  <label>New Password:</label><br>
                  <input type="password" name="new_password" required><br>
                  <label>Confirm New Password:</label><br>
                  <input type="password" name="confirm_new_password" required><br><br>
                  <button type="submit" name="change_password">Submit</button>
                </form>
              </div>';
              echo '</div>';
    } else {
        echo "<p>User profile not found.</p>";
    }
    $stmt1->close(); // Close the prepared statement
}

// Handle Change Password Request
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];

    if ($new_password !== $confirm_new_password) {
        echo "<p>New passwords do not match.</p>";
    } else {
        $password_query = "SELECT password FROM users WHERE userID = ?";
        if ($stmt2 = $conn->prepare($password_query)) {
            $stmt2->bind_param("i", $userID);
            $stmt2->execute();
            $result = $stmt2->get_result();
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                $hashed_password = $user['password'];
                if (password_verify($current_password, $hashed_password)) {
                    $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_query = "UPDATE users SET password = ? WHERE userID = ?";
                    if ($stmt3 = $conn->prepare($update_query)) {
                        $stmt3->bind_param("si", $new_hashed_password, $userID);
                        if ($stmt3->execute()) {
                            // Password successfully updated
                            session_destroy(); // Log out the user
                            header("Location: index.html?message=password-updated"); // Redirect to index.html with message
                            exit();
                        } else {
                            echo "<p>Error updating the password.</p>";
                        }
                        $stmt3->close();
                    }
                } else {
                    echo "<p>Current password is incorrect.</p>";
                }
            }
            $stmt2->close();
        }
    }
}

// Check if the user clicked the delete button
if (isset($_POST['delete_account'])) {
    $delete_query = "DELETE FROM users WHERE userID = ?";
    if ($stmt4 = $conn->prepare($delete_query)) {
        $stmt4->bind_param("i", $userID);
        if ($stmt4->execute()) {
            session_destroy();
            echo "<p>Your account has been deleted. You will be logged out.</p>";
            header("Location: index.html");
            exit();
        } else {
            echo "<p>There was an error deleting your account.</p>";
        }
        $stmt4->close();
    }
}

// Check if the user clicked the logout button
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: index.html");
    exit();
}

$conn->close();
?>
<script>
    document.getElementById('changePasswordBtn').addEventListener('click', function() {
        var form = document.getElementById('changePasswordForm');
        form.style.display = form.style.display === 'none' ? 'block' : 'none';
    });
</script>
</body>
</html>
