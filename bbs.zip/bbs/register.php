<?php
// Start the session
session_start();

// Database connection details
$host = "localhost"; // Database host
$dbUsername = "root"; // Database username
$dbPassword = ""; // Database password
$dbName = "registration"; // Database name

// Create a connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    // Check if passwords match
    if ($password !== $confirmPassword) {
        echo "<p style='color: red;'>Passwords do not match.</p>";
        exit();
    }

    // Check if username or email already exists
    $checkQuery = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($checkQuery);

    if ($result->num_rows > 0) {
        echo "<p style='color: red;'>This email is already registered. Please try a different one.</p>";
        exit();
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Insert data into the `users` table
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashedPassword')";

    if ($conn->query($sql) === TRUE) {
        // Get the last inserted ID
        $userID = $conn->insert_id;

        // Store the userID in the session
        $_SESSION['userID'] = $userID;

        // Redirect to homepage after successful registration
        header("Location: homepage.html");
        exit();
    } else {
        echo "<p style='color: red;'>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }
}

// Close the connection
$conn->close();
?>
