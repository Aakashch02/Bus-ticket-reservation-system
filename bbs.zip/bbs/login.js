/* function validateForm() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');
    
    if (username === '' || password === '') {
      errorMessage.textContent = 'password does not match';
      return false;
    }
    
    // You can add additional validations here if needed
    
    errorMessage.textContent = '';
    return true;
  }
   */