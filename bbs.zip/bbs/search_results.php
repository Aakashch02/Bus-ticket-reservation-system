<?php
// Include the database connection file
include('db_connection.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the selected cities from the form
    $departure_city = $_POST['departure_city'];
    $destination_city = $_POST['destination_city'];

    // SQL query to fetch buses based on selected cities
    $query = "SELECT * FROM buses WHERE `from` = ? AND `to` = ?";
    
    // Prepare the statement
    if ($stmt = $conn->prepare($query)) {
        // Bind the parameters
        $stmt->bind_param("ss", $departure_city, $destination_city);
        
        // Execute the query
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();
        
        // Start outputting HTML
        echo '<!DOCTYPE html>
              <html>
              <head>
                  <title>Available Buses</title>
                  <link rel="stylesheet"  href="search.css">
              </head>
              <body>';

        // Check if buses are found
        if ($result->num_rows > 0) {
            // Display the available buses
            echo "<h2>Available Buses from $departure_city to $destination_city</h2>";
            echo "<table>
                    <tr>
                        <th>Bus Number</th>
                        <th>Capacity</th>
                        <th>Action</th>
                    </tr>";

            // Fetch each bus detail
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row['busnumber'] . "</td>
                        <td>" . $row['capacity'] . "</td>
                        <td>
                            <a href='confirm_booking.php?busNumber=" . $row['busnumber'] . "&from=" . $departure_city . "&to=" . $destination_city . "'>
                                <button>Book Now</button>
                            </a>
                        </td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "<p class='no-results'>No buses found for the selected route.</p>";
        }

        echo '</body></html>';
        
        // Close the prepared statement
        $stmt->close();
    } else {
        echo "Error in preparing the query.";
    }
}

// Close the database connection
$conn->close();
?>
