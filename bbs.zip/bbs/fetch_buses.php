<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";  // Default password for MySQL in XAMPP
$dbname = "registration";  // Your database name

$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted (Search is clicked)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $from = $_POST['from'];
    $to = $_POST['to'];
    $date = $_POST['date'];

    // SQL query to fetch buses from the buses table based on the search criteria
    $sql = "SELECT * FROM buses WHERE source = '$from' AND destination = '$to'"; 

    // Execute query and check if there are any results
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        // Loop through and display the bus details
        while ($row = mysqli_fetch_assoc($result)) {
            echo "Bus Number: " . $row['busNumber'] . "<br>";
            echo "Capacity: " . $row['capacity'] . "<br><br>";
        }
    } else {
        echo "No buses found for the selected route.";
    }
}
?>

<!-- HTML Form -->
<form action="" method="POST">
    <label for="from">From:</label>
    <select name="from" id="from">
        <option value="Kathmandu">Kathmandu</option>
        <option value="Chitwan">Chitwan</option>
        <!-- Add other cities here -->
    </select>

    <label for="to">To:</label>
    <select name="to" id="to">
        <option value="Chitwan">Chitwan</option>
        <option value="Kathmandu">Kathmandu</option>
        <!-- Add other cities here -->
    </select>

    <label for="date">Date:</label>
    <input type="date" name="date" id="date">

    <button type="submit">Search</button>
</form>
