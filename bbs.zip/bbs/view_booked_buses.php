<?php
// Include the database connection file
include('db_connection.php');
session_start(); // Start session to capture userID

// Check if the user is logged in (Ensure userID is available)
if (!isset($_SESSION['userID'])) {
    echo "Please log in to view your booked buses.";
    exit;
}

// Get the logged-in user's ID
$userID = $_SESSION['userID'];

// SQL query to fetch the user's booked buses
$query = "SELECT r.reservationID, r.from, r.to, r.bookdate, r.busNumber, b.capacity 
          FROM reservation r 
          INNER JOIN buses b ON r.busNumber = b.busNumber
          WHERE r.userID = ?";

// Prepare the statement
if ($stmt = $conn->prepare($query)) {
    // Bind the parameters
    $stmt->bind_param("i", $userID);
    
    // Execute the query
    $stmt->execute();
    
    // Get the result
    $result = $stmt->get_result();
    echo '<!DOCTYPE html>
              <html>
              <head>
                  <title>Available Buses</title>
                  <link rel="stylesheet"  href="search.css">
              </head>
              <body>';
    
    // Check if the user has any bookings
    if ($result->num_rows > 0) {
        // Display the booked buses
        echo "<h2>Your Booked Buses</h2>";
        echo "<table border='1'>
                <tr>
                    <th>Reservation ID</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Booking Date</th>
                    <th>Bus Number</th>
                    <th>Capacity</th>
                    <th>Action</th>
                </tr>";

        // Fetch each reservation detail
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row['reservationID'] . "</td>
                    <td>" . $row['from'] . "</td>
                    <td>" . $row['to'] . "</td>
                    <td>" . $row['bookdate'] . "</td>
                    <td>" . $row['busNumber'] . "</td>
                    <td>" . $row['capacity'] . "</td>
                    <td>
                        <form method='POST' action='cancel_booking.php' style='display: inline;'>
                            <input type='hidden' name='reservationID' value='" . $row['reservationID'] . "'>
                            <button type='submit' onclick='return confirm(\"Are you sure you want to cancel this booking?\");'>Cancel</button>
                        </form>
                    </td>
                </tr>";
        }

        echo "</table>";
    } else {
        echo "<p>You have no booked buses.</p>";
    }
    
    // Close the prepared statement
    $stmt->close();
} else {
    echo "Error in preparing the query.";
}

// Close the database connection
$conn->close();
?>
