<?php
// Include the database connection file
include('db_connection.php');
session_start(); // Start session

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    echo "Please log in to cancel your booking.";
    exit;
}

// Check if the reservationID is provided
if (isset($_POST['reservationID'])) {
    $reservationID = $_POST['reservationID'];

    // SQL query to delete the booking
    $delete_query = "DELETE FROM reservation WHERE reservationID = ?";

    if ($stmt = $conn->prepare($delete_query)) {
        $stmt->bind_param("i", $reservationID);

        if ($stmt->execute()) {
            echo "<p>Booking has been canceled successfully.</p>";
            header("Location: homepage.html"); // Redirect back to the booked buses page
            exit;
        } else {
            echo "<p>Failed to cancel the booking. Please try again.</p>";
        }

        $stmt->close();
    } else {
        echo "<p>Error in preparing the query.</p>";
    }
} else {
    echo "<p>Invalid request. Reservation ID is missing.</p>";
}

// Close the database connection
$conn->close();
?>
