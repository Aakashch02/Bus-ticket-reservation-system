document.getElementById('registrationForm').addEventListener('submit', function(event) {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;

    if (password !== confirmPassword) {
        event.preventDefault(); // Prevent form submission
        document.getElementById('error-message').textContent = "Passwords do not match!";
    }
});
