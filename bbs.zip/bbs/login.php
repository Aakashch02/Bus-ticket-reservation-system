<?php
// Start the session
session_start();

// Database connection details
$servername = "localhost"; // Database host
$username = "root"; // Database username
$password = ""; // Database password
$dbname = "registration"; // Database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Query to fetch user data
    $sql = "SELECT userID, password FROM users WHERE email= '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch user data
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];
        $userID = $row['userID'];

        // Verify password
        if (password_verify($password, $hashedPassword)) {
            // Store user ID in session
            $_SESSION['userID'] = $userID;

            // Redirect to homepage
            header("Location: homepage.html ");
            exit(); // Ensure the script stops executing after redirection
        } else {
            echo "<p style='color: red;'>Invalid password. Please try again.</p>";
        }
    } else {
        echo "<p style='color: red;'>email not found. Please try again.</p>";
    }
}

// Close the connection
$conn->close();
?>
