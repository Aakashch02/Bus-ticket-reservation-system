<?php
// Include the database connection file
include('db_connection.php');
session_start(); // Start session to capture userID

// Check if the user is logged in (Ensure userID is available)
if (!isset($_SESSION['userID'])) {
    echo "Please log in to book a bus.";
    exit;
}

// Get the bus details and userID
$busNumber = $_GET['busNumber'];
$departure_city = $_GET['from'];
$destination_city = $_GET['to'];
$userID = $_SESSION['userID']; // Capture the logged-in user ID

// Get the current date for booking
$bookdate = date('Y-m-d');

// SQL query to insert the reservation into the table
$query = "INSERT INTO reservation (userID, `from`, `to`, bookdate, busNumber) VALUES (?, ?, ?, ?, ?)";

// Prepare the statement
if ($stmt = $conn->prepare($query)) {
    // Bind the parameters
    $stmt->bind_param("issss", $userID, $departure_city, $destination_city, $bookdate, $busNumber);
    
    // Execute the query
    if ($stmt->execute()) {
        // Booking confirmed, redirect to homepage.html with a success query parameter
        header("Location: homepage.html?booking=success");
        exit; // Ensure no further code is executed
    } else {
        echo "<p>There was an error with the booking.</p>";
    }
    
    // Close the prepared statement
    $stmt->close();
} else {
    echo "Error in preparing the query.";
}

// Close the database connection
$conn->close();
?>
