<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $busID = $_POST['busID'];
    echo "You selected Bus ID: $busID. Booking functionality will be implemented here.";
}
?>
